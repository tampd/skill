---
name: Perf — Core Web Vitals & Frontend Performance
description: "Audit và tối ưu hiệu suất website: Core Web Vitals (LCP/CLS/INP), image optimization, bundle analysis, caching strategy, Lighthouse CI. Dùng khi website chậm, score Lighthouse thấp, hoặc cần optimize trước khi launch. Kích hoạt bằng /perf [target]."
---

# /perf [target: page | bundle | images | all]

> **Performance Engineer** — Core Web Vitals, Lighthouse CI, Real User Monitoring
> Mục tiêu: Lighthouse score ≥ 90 mọi category. LCP < 2.5s. CLS < 0.1. INP < 200ms.

> [!CAUTION]
> **RULE**: KHÔNG optimize premature. Profile trước, optimize sau. Evidence-driven ONLY.

---

## TARGETS BẮT BUỘC (Production Baseline)

| Metric | Target | Công cụ |
|---|---|---|
| **LCP** (Largest Contentful Paint) | < 2.5s | Lighthouse, CrUX |
| **CLS** (Cumulative Layout Shift) | < 0.1 | Lighthouse, Web Vitals |
| **INP** (Interaction to Next Paint) | < 200ms | Web Vitals JS |
| **FCP** (First Contentful Paint) | < 1.8s | Lighthouse |
| **TTFB** (Time to First Byte) | < 600ms | Lighthouse |
| **Lighthouse Performance** | ≥ 90 | `npx lighthouse` |
| **Lighthouse Accessibility** | ≥ 90 | Lighthouse |
| **Lighthouse Best Practices** | ≥ 95 | Lighthouse |
| **Lighthouse SEO** | ≥ 95 | Lighthouse |
| **Bundle Size (First Load JS)** | < 150KB gzip | next-bundle-analyzer |

---

## QUY TRÌNH AUDIT

### Phase 1 — MEASURE (Không skip)

```bash
# Lighthouse CLI — Run từ production URL
npx lighthouse https://yoursite.com \
  --output=json \
  --output-path=./perf-report.json \
  --only-categories=performance,accessibility,best-practices,seo \
  --form-factor=mobile \
  --throttling-method=simulate

# Bundle analysis (Next.js)
ANALYZE=true next build
# Hoặc:
npx @next/bundle-analyzer

# Web Vitals measurement code (thêm vào app)
import { onLCP, onCLS, onINP, onFCP, onTTFB } from 'web-vitals'

function sendToAnalytics(metric) {
  const body = JSON.stringify(metric)
  navigator.sendBeacon('/api/vitals', body)
}

onLCP(sendToAnalytics)
onCLS(sendToAnalytics)
onINP(sendToAnalytics)
```

### Phase 2 — DIAGNOSE

```
PROFILING ORDER (từ impact cao → thấp):
1. Network requests (waterfall analysis)
2. JavaScript bundle size + parse time
3. Image size + format
4. Render-blocking resources
5. Third-party scripts
6. Server response time (TTFB)
```

---

## MODE 1 — `/perf images` (Image Optimization)

```
IMAGE CHECKLIST:
[ ] Dùng next/image hoặc <img loading="lazy"> thay thủ công?
[ ] Format: WebP cho photography, AVIF cho maximum compression, SVG cho icons
[ ] Responsive srcset: cung cấp 3 kích thước (480w, 768w, 1200w)
[ ] Explicit width + height (tránh CLS)
[ ] LCP image: loading="eager" priority={true} — KHÔNG lazy load
[ ] Alt text: mọi img PHẢI có alt (kể cả alt="" nếu decorative)

IMAGE SIZING RULE:
  width=100vw → 480, 768, 1200 breakpoints
  width=50vw  → 240, 384, 600 breakpoints
  Thumbnails  → 1x + 2x (80px → 80, 160)
```

```typescript
// ✅ Next.js Image best practice
import Image from 'next/image'

// Above the fold (LCP candidate) — KHÔNG lazy load
<Image
  src="/hero.webp"
  alt="Hero image mô tả content"
  width={1200}
  height={600}
  priority          // preload + eager load
  sizes="100vw"
  quality={85}
/>

// Below the fold — lazy load (default)
<Image
  src="/product.webp"
  alt="Tên sản phẩm"
  width={400}
  height={300}
  sizes="(max-width: 768px) 100vw, 400px"
/>
```

---

## MODE 2 — `/perf bundle` (JavaScript Optimization)

```
BUNDLE ANALYSIS CHECKLIST:
[ ] First Load JS < 150KB gzip?
[ ] Code splitting: dynamic imports cho heavy components?
[ ] Tree shaking: import { specific } thay import * as ?
[ ] Duplicate deps: check bundle-analyzer cho duplicates?
[ ] Third-party scripts: loaded async/defer?
[ ] Unused exports/code: check với eslint no-unused-vars?
```

```typescript
// ✅ Dynamic import cho heavy components (tránh blocking)
const RichTextEditor = dynamic(
  () => import('@/components/organisms/RichTextEditor'),
  {
    loading: () => <Skeleton className="h-64 w-full" />,
    ssr: false  // Editor thường cần browser APIs
  }
)

// ✅ Route-based code splitting (Next.js tự làm)
// ✅ Import specific thay vì full library
import { format, parseISO } from 'date-fns'  // ✅
import * as dateFns from 'date-fns'          // ❌ → import whole library

// ✅ Lazy load heavy libs
const Chart = lazy(() => import('recharts').then(m => ({ default: m.LineChart })))
```

---

## MODE 3 — `/perf render` (Render Performance)

### LCP Optimization

```
LCP CAUSES & FIXES:
1. Slow TTFB (server response) → CDN, caching, server optimization
2. Render-blocking resources → preload LCP image, defer non-critical CSS
3. Slow resource load time → Image optimization, CDN với edge caching
4. Client-side rendering → Use SSR/SSG cho above-fold content

PRELOAD LCP IMAGE:
```html
<link
  rel="preload"
  as="image"
  href="/hero.webp"
  imagesrcset="/hero-480.webp 480w, /hero-1200.webp 1200w"
  imagesizes="100vw"
/>
```

### CLS Optimization

```
CLS CAUSES & FIXES:
1. Images without dimensions → LUÔN set width/height
2. Ads/embeds without dimensions → reserve space với aspect-ratio
3. Late-injected content → skeleton loaders với fixed dimensions
4. Web fonts → font-display: swap + preload + size-adjust

FONT LOADING:
```css
/* Prevent FOUT gây CLS */
@font-face {
  font-family: 'Inter';
  src: url('/fonts/inter.woff2') format('woff2');
  font-display: swap;
  size-adjust: 100%;  /* Prevents layout shift vs system font */
}
```

```html
<!-- Preload critical fonts -->
<link rel="preload" href="/fonts/inter.woff2" as="font" type="font/woff2" crossorigin>
```

### INP Optimization

```
INP CAUSES & FIXES:
1. Long tasks (>50ms) → Break với scheduler.yield() hoặc requestAnimationFrame
2. Heavy event handlers → Debounce input, throttle scroll/resize
3. Large DOM → Virtualize lists > 100 items
4. Blocking third-party scripts → Async load, use Partytown

VIRTUALIZED LIST:
```typescript
import { useVirtualizer } from '@tanstack/react-virtual'

// Cho lists > 100 items
function VirtualList({ items }) {
  const parentRef = useRef(null)
  const virtualizer = useVirtualizer({
    count: items.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 60,  // estimated row height
  })
  ...
}
```

---

## MODE 4 — `/perf caching` (Caching Strategy)

```
CACHING HIERARCHY:
1. Browser Cache (Cache-Control headers)
2. CDN/Edge Cache (Vercel Edge, CloudFlare)
3. Server Memory Cache (Redis)
4. Database Query Cache

HTTP CACHE HEADERS:
```
# Static assets (JS, CSS, images với content hash)
Cache-Control: public, max-age=31536000, immutable

# HTML pages (revalidate thường xuyên)
Cache-Control: public, max-age=0, s-maxage=3600, stale-while-revalidate=86400

# API responses (private, không cache ở CDN)
Cache-Control: private, no-cache

# API responses có thể share (public không sensitive)
Cache-Control: public, s-maxage=60, stale-while-revalidate=300
```

```typescript
// Next.js fetch caching
// Static với revalidation
const data = await fetch('/api/products', {
  next: { revalidate: 3600 }  // Revalidate mỗi giờ
})

// Force dynamic (no cache)
const user = await fetch('/api/me', {
  cache: 'no-store'
})
```

---

## OUTPUT FORMAT

```
⚡ PERF REPORT — [URL / Component]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 LIGHTHOUSE SCORES
  Performance:      [score]/100  [✅ ≥90 | ⚠️ 70-89 | 🛑 <70]
  Accessibility:    [score]/100
  Best Practices:   [score]/100
  SEO:              [score]/100

📈 CORE WEB VITALS
  LCP: [value]  [✅ <2.5s | ⚠️ 2.5-4s | 🛑 >4s]
  CLS: [value]  [✅ <0.1 | ⚠️ 0.1-0.25 | 🛑 >0.25]
  INP: [value]  [✅ <200ms | ⚠️ 200-500ms | 🛑 >500ms]

📦 BUNDLE SIZE
  First Load JS: [size] gzip  [✅ <150KB | ⚠️ 150-250KB | 🛑 >250KB]

🔴 CRITICAL ISSUES (must fix before launch)
  1. [Issue] — [Impact] — [Fix]

🟡 WARNINGS (fix soon)
  1. [Issue] — [Impact] — [Fix]

✅ PASSING
  [List items passing]
```
