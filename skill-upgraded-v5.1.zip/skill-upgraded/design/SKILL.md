---
name: Design — UI/UX Production Workflow (v5.1)
description: "Quy trình design toàn diện: brief → token system → Atomic components → implement → a11y check → visual verify. Dùng khi thiết kế UI/UX, tạo component, implement design system, hoặc cần dark mode. Kích hoạt bằng /design [task]."
---

# /design [task description]

> **UI/UX Architect** — Đẹp, Accessible, Responsive, Kế thừa được
> Mục tiêu: UI đẹp + WCAG AA compliant + dark mode sẵn + animation mượt

> [!IMPORTANT]
> **3 RULES không ngoại lệ:**
> 1. KHÔNG hardcode colors — dùng semantic tokens
> 2. PHẢI test contrast ratio ≥ 4.5:1 (WCAG AA)
> 3. PHẢI prefers-reduced-motion cho mọi animation

---

## QUY TRÌNH 6 BƯỚC

### Step 1 — BRIEF
```
1. Đọc GEMINI.md → design system hiện có, CSS variables
2. Đọc LESSONS.md → grep #css, #blade, #theme, #ui, #a11y
3. Xác định:
   - Atomic level? (atom/molecule/organism/template/page)
   - Screen nào? Target users? (admin/employee/public)
   - Responsive: desktop/tablet/mobile
   - Dark mode? Light mode? Both?
   - Interactive elements cần ARIA attributes nào?
```

### Step 2 — DESIGN SYSTEM CHECK
```
1. Semantic Tokens hiện có (từ design-system/semantics.css):
   --bg-surface, --bg-card, --text-primary, --text-secondary
   --color-brand, --border-color, --focus-ring
   → LUÔN dùng semantic tokens, KHÔNG dùng primitive tokens trực tiếp
   → KHÔNG hardcode colors (#3b82f6 → var(--color-brand))

2. Component patterns đã có:
   → Check components/atoms/, components/molecules/, components/organisms/
   → Reuse trước khi tạo mới

3. Spacing system: 4px base (--space-1=4px, --space-2=8px, ...)

4. Typography scale: --text-sm=14px, --text-base=16px, --text-lg=18px...
```

### Step 3 — IMPLEMENT (với ARIA first)

> ⚠️ **TDD Exception**: CSS-only = visual verify. Component có logic = BẮT BUỘC TDD.

```
CODING CHECKLIST mỗi component:

ACCESSIBILITY (WCAG AA — BẮT BUỘC):
[ ] Semantic HTML (button vs div, nav vs div, main/header/footer)
[ ] Role attribute khi cần (role="alert", role="dialog", role="tab")
[ ] aria-label cho icons, buttons không có visible text
[ ] aria-describedby cho form errors
[ ] aria-live="polite" cho dynamic content
[ ] aria-expanded cho accordion/menu
[ ] aria-busy cho loading states
[ ] Tabindex: chỉ 0 hoặc -1, KHÔNG positive tabindex
[ ] Focus visible: KHÔNG xóa outline, thay thế bằng focus-ring đẹp

INTERACTIVITY:
[ ] Keyboard: Enter/Space activate buttons; arrow keys cho menus
[ ] Touch target ≥ 44×44px (mobile)
[ ] Hover state
[ ] Active/pressed state
[ ] Disabled state (aria-disabled + visual)
[ ] Loading state (aria-busy + spinner)
[ ] Error state (aria-invalid + aria-describedby)

THEMING:
[ ] Light mode: đủ contrast với --text-primary / --bg-surface
[ ] Dark mode: đủ contrast với dark theme tokens
[ ] High contrast: test với prefers-contrast: high
```

```typescript
// ✅ Accessible Button với tất cả states
<button
  className={cn(
    'btn',
    variant === 'primary' && 'btn--primary',
    isLoading && 'btn--loading'
  )}
  aria-busy={isLoading}
  aria-disabled={isLoading || disabled}
  disabled={isLoading || disabled}
  onClick={!isLoading && !disabled ? onClick : undefined}
>
  {isLoading && <Spinner aria-hidden="true" size="sm" />}
  <span className={isLoading ? 'sr-only' : ''}>{children}</span>
  {isLoading && <span className="sr-only">Loading...</span>}
</button>

// ✅ Accessible Form Field
<div className="form-field">
  <label htmlFor={fieldId} className="form-label">
    {label}
    {required && <span aria-hidden="true" className="text-error"> *</span>}
    {required && <span className="sr-only"> (required)</span>}
  </label>
  <input
    id={fieldId}
    aria-describedby={error ? `${fieldId}-error` : undefined}
    aria-invalid={!!error}
    aria-required={required}
    className={cn('form-input', error && 'form-input--error')}
    {...props}
  />
  {error && (
    <p id={`${fieldId}-error`} role="alert" className="form-error">
      {error}
    </p>
  )}
</div>
```

### Step 3.5 — ANIMATION SYSTEM

```css
/* design-system/animations.css */
:root {
  --duration-fast: 150ms;
  --duration-normal: 250ms;
  --duration-slow: 400ms;
  --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
  --ease-out: cubic-bezier(0, 0, 0.2, 1);
  --ease-spring: cubic-bezier(0.175, 0.885, 0.32, 1.275);
  --ease-bounce: cubic-bezier(0.34, 1.56, 0.64, 1);
}

/* BẮT BUỘC: Respect user's motion preference */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}

/* Pattern: Fade In */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Pattern: Skeleton shimmer */
@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}

.skeleton {
  background: linear-gradient(
    90deg,
    var(--bg-muted) 25%,
    var(--bg-elevated) 50%,
    var(--bg-muted) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
}
```

```typescript
// ✅ Animation patterns với Framer Motion
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'

// Tự động tắt animation nếu user prefer
const shouldReduceMotion = useReducedMotion()

const variants = {
  hidden: { opacity: 0, y: shouldReduceMotion ? 0 : 8 },
  visible: { opacity: 1, y: 0 },
  exit: { opacity: 0, scale: shouldReduceMotion ? 1 : 0.95 }
}

// AnimatePresence cho unmount animations
<AnimatePresence mode="wait">
  {isOpen && (
    <motion.div
      key="modal"
      variants={variants}
      initial="hidden"
      animate="visible"
      exit="exit"
      transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
    >
      {children}
    </motion.div>
  )}
</AnimatePresence>
```

### Step 4 — COMPONENT API DOCS (BẮT BUỘC)

```markdown
## [ComponentName]

### Purpose
[Khi nào dùng component này? 1-2 câu. Khi nào KHÔNG dùng?]

### Props / API
| Prop | Type | Default | Required | Mô tả |
|------|------|---------|----------|-------|
| variant | 'primary' \| 'secondary' \| 'ghost' | 'primary' | No | Visual style |
| size | 'sm' \| 'md' \| 'lg' | 'md' | No | Kích thước |
| isLoading | boolean | false | No | Loading state |
| children | ReactNode | - | Yes | Content |

### States & Visual
| State | Trigger | Visual | ARIA |
|-------|---------|--------|------|
| Default | - | Blue bg, white text | - |
| Hover | :hover | Darker bg | - |
| Focus | :focus-visible | Focus ring | - |
| Disabled | disabled prop | Muted, cursor-not-allowed | aria-disabled |
| Loading | isLoading prop | Spinner + sr-only text | aria-busy |

### Accessibility
- Keyboard: Enter/Space to activate
- Screen reader: announces label + state changes
- Focus: custom focus ring via --focus-ring
- Contrast: verified ≥ 4.5:1 on light + dark

### Usage Examples
```tsx
// Basic
<Button>Click me</Button>

// With loading
<Button isLoading={isSubmitting}>Submit</Button>

// Destructive action
<Button variant="destructive" aria-label="Delete account permanently">
  Delete Account
</Button>
```

### Responsive Behavior
- Touch target ≥ 44×44px trên mobile
- Full-width option trên mobile: className="w-full sm:w-auto"
```

### Step 5 — VISUAL VERIFY (Evidence bắt buộc)

```
1. Desktop (1440px): Layout đúng? Spacing đủ?
2. Tablet (768px): Responsive? Grid adapt?
3. Mobile (375px): Touch targets ≥ 44px? Text readable?
4. Dark mode (data-theme="dark"): Contrast đủ? No hardcoded grays?
5. High contrast (prefers-contrast: high): Readable?
6. Reduced motion: Animations disabled/minimal?
7. axe DevTools: 0 violations
8. Screenshot mỗi state → attach evidence
```

### Step 6 — ACCESSIBILITY AUDIT

```
WCAG 2.2 AA CHECKLIST (mỗi component mới):

PERCEIVABLE:
[ ] Text alternatives: mọi img có alt, icon có aria-label
[ ] Color contrast: ≥ 4.5:1 text, ≥ 3:1 large text (≥18px bold / ≥24px)
[ ] Info không phụ thuộc chỉ vào color
[ ] Captions/transcripts cho video/audio

OPERABLE:
[ ] Keyboard accessible: Tab order logic, không trap focus (trừ modal)
[ ] Focus visible: rõ ràng, không bị ẩn
[ ] Touch target ≥ 24×24px CSS (khuyến nghị 44×44)
[ ] No keyboard shortcut conflicts

UNDERSTANDABLE:
[ ] Language: lang attr trên <html>
[ ] Error messages: specific, actionable
[ ] Labels: form inputs có label associated
[ ] Consistent navigation

ROBUST:
[ ] Valid HTML (không nesting div trong p, button trong button)
[ ] ARIA correct (role, state, property)
[ ] Status messages: role="status" hoặc role="alert"
```

---

## DESIGN SYSTEM TOKEN TABLE (Reference)

| Token | Light Value | Dark Value | Usage |
|-------|------------|-----------|-------|
| --bg-page | #f9fafb | #111827 | Page background |
| --bg-surface | #ffffff | #1f2937 | Card, panel bg |
| --text-primary | #111827 | #f9fafb | Body text |
| --text-secondary | #6b7280 | #9ca3af | Subtext |
| --color-brand | #2563eb | #60a5fa | Primary actions |
| --border-color | #e5e7eb | #374151 | Dividers, borders |
| --focus-ring | blue 3px | blue 3px | Focus state |

---

## QUY TẮC

- ❌ KHÔNG hardcode colors, fonts, spacing
- ❌ KHÔNG dùng div/span khi có semantic element phù hợp
- ❌ KHÔNG xóa focus outline mà không thay thế
- ❌ KHÔNG animation mà không có prefers-reduced-motion fallback
- ✅ LUÔN test 3 breakpoints + dark mode + axe DevTools
- ✅ LUÔN attach screenshot evidence cho visual changes
- ✅ LUÔN viết Component API docs cho organisms mới
