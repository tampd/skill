---
name: Frontend — Website Architecture Foundation
description: "Thiết lập kiến trúc frontend production-grade cho website: Atomic Design System, TypeScript strict, CSS architecture, component structure, state management, file conventions. Dùng khi bắt đầu dự án web mới, setup component library, hoặc cần refactor architecture frontend. Kích hoạt bằng /frontend [task]."
---

# /frontend [task description]

> **Website Architecture Foundation** — Kiến trúc bền vững, kế thừa được, dễ sửa
> Mục tiêu: Codebase mà AI hoặc developer mới tiếp quản 100% không mơ hồ

> [!IMPORTANT]
> **RULE**: Mọi component PHẢI follow Atomic Design. PHẢI có Component API docs. PHẢI dùng Design Tokens.

---

## KHI NÀO DÙNG

| Tình huống | Dùng /frontend? |
|---|---|
| Bắt đầu dự án web mới | ✅ `/frontend setup` |
| Tạo component library | ✅ `/frontend components` |
| Refactor file structure | ✅ `/frontend restructure` |
| Setup TypeScript strict | ✅ `/frontend typescript` |
| Chọn CSS methodology | ✅ `/frontend css` |
| Fix bug UI cụ thể | ❌ → `/fix` |
| Thiết kế UI/UX cụ thể | ❌ → `/design` |

---

## MODE 1 — `/frontend setup` (Dự án mới)

### Step 1 — STACK DECISION

```
Hỏi user để chọn stack phù hợp:

FRAMEWORK:
  A) Next.js 15+ (App Router)  — Full-stack, SSR/SSG, SEO tốt nhất ⭐
  B) Nuxt 3                    — Vue ecosystem, SSR
  C) Astro                     — Content sites, islands architecture
  D) Vite + React/Vue          — SPA thuần

CSS METHODOLOGY:
  A) Tailwind CSS v4           — Utility-first, token system mạnh ⭐
  B) CSS Modules + Vanilla     — Scoped, không dependency
  C) Styled Components/Emotion — CSS-in-JS (chỉ dùng nếu team quen)

LANGUAGE:
  → TypeScript (strict) — BẮT BUỘC. KHÔNG plain JS.

STATE:
  A) Zustand                   — Simple, lightweight ⭐
  B) TanStack Query            — Server state, cache
  C) Redux Toolkit             — Complex enterprise
  D) Jotai                     — Atomic state
```

### Step 2 — FILE STRUCTURE CONVENTION

```
src/
├── app/                    ← Next.js App Router (hoặc pages/)
│   ├── (auth)/             ← Route groups
│   ├── (dashboard)/
│   └── globals.css
│
├── components/             ← Atomic Design
│   ├── atoms/              ← Smallest: Button, Input, Badge, Icon
│   ├── molecules/          ← Composed: SearchBar, FormField, Card
│   ├── organisms/          ← Complex: Header, Sidebar, DataTable
│   ├── templates/          ← Page layouts: DashboardLayout, AuthLayout
│   └── pages/              ← Route-specific: HomePage, ProfilePage
│
├── design-system/          ← Design tokens & base styles
│   ├── tokens.css          ← CSS custom properties (primitives)
│   ├── semantics.css       ← Semantic tokens mapped from primitives
│   └── animations.css      ← Motion tokens & keyframes
│
├── lib/                    ← Utilities & helpers
│   ├── utils.ts            ← Generic utilities
│   ├── validations.ts      ← Zod schemas
│   └── constants.ts        ← App-wide constants
│
├── hooks/                  ← Custom React hooks
│   ├── useAuth.ts
│   └── useLocalStorage.ts
│
├── services/               ← API layer
│   ├── api.ts              ← Base API client (axios/fetch)
│   ├── auth.service.ts
│   └── user.service.ts
│
├── stores/                 ← State management
│   ├── auth.store.ts
│   └── ui.store.ts
│
├── types/                  ← TypeScript type definitions
│   ├── api.types.ts        ← API response types
│   ├── domain.types.ts     ← Business domain types
│   └── global.d.ts         ← Global declarations
│
└── __tests__/              ← Test files mirror src structure
    ├── components/
    └── hooks/
```

### Step 3 — TYPESCRIPT STRICT CONFIG

```typescript
// tsconfig.json — BẮT BUỘC strict mode
{
  "compilerOptions": {
    "strict": true,                    // Bật TẤT CẢ strict checks
    "noUncheckedIndexedAccess": true,  // Array access luôn T | undefined
    "exactOptionalPropertyTypes": true, // ? props không nhận undefined
    "noImplicitReturns": true,         // Mọi code path PHẢI return
    "noFallthroughCasesInSwitch": true,// switch case PHẢI có break/return
    "noImplicitOverride": true,        // extends PHẢI dùng override keyword
    "allowImportingTsExtensions": true,// Import .ts trực tiếp
    "paths": {
      "@/*": ["./src/*"],              // Path aliases
      "@components/*": ["./src/components/*"],
      "@design/*": ["./src/design-system/*"]
    }
  }
}
```

```typescript
// ✅ Đúng — Typed props, no any
interface ButtonProps {
  variant: 'primary' | 'secondary' | 'ghost' | 'destructive'
  size?: 'sm' | 'md' | 'lg'
  isLoading?: boolean
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void
  children: React.ReactNode
}

// ❌ Sai — VI PHẠM = BUG
function Button(props: any) { ... }
const data: any = await fetch(...)
```

---

## MODE 2 — `/frontend components` (Atomic Design)

### Atomic Design Principles

```
ATOMS — Không thể chia nhỏ hơn:
  Button, Input, Label, Badge, Avatar, Icon, Spinner, Divider
  → KHÔNG có business logic
  → PHẢI accept className prop
  → PHẢI forward ref
  → PHẢI có aria attributes

MOLECULES — Ghép 2+ atoms:
  SearchBar (Input + Button + Icon)
  FormField (Label + Input + ErrorMessage)
  Toast (Icon + Text + CloseButton)
  → Xử lý local state của nhóm đó
  → KHÔNG biết về global state

ORGANISMS — Business components:
  Header (Logo + Navigation + UserMenu)
  DataTable (Pagination + Rows + Filters + SortHeaders)
  ProductCard (Image + Info + PriceTag + AddToCart)
  → CÓ THỂ connect với global state
  → CÓ THỂ fetch data (Server Components)

TEMPLATES — Layout shells:
  DashboardLayout (Sidebar + Header + Main)
  AuthLayout (Logo + Form + Footer)
  → KHÔNG có business data, chỉ slots/children

PAGES — Actual routes:
  → Kết nối templates + organisms + data
  → SEO metadata ở đây
```

### Component Naming Convention

```typescript
// File: components/atoms/Button/index.tsx
// ✅ PascalCase component name
// ✅ Props interface = ComponentName + Props
// ✅ Named export + default export

export interface ButtonProps { ... }

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', isLoading, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant, size }), props.className)}
        aria-busy={isLoading}
        disabled={isLoading || props.disabled}
        {...props}
      >
        {isLoading ? <Spinner size="sm" aria-hidden /> : children}
      </button>
    )
  }
)

Button.displayName = 'Button'  // BẮT BUỘC cho forwardRef
export default Button
```

### Component Barrel Exports

```typescript
// components/atoms/index.ts — Barrel file
export { Button } from './Button'
export type { ButtonProps } from './Button'
export { Input } from './Input'
export type { InputProps } from './Input'
// ...

// components/index.ts — Root barrel
export * from './atoms'
export * from './molecules'
export * from './organisms'

// Usage — Clean import
import { Button, Input, FormField } from '@/components'
```

---

## MODE 3 — `/frontend css` (CSS Architecture)

### Design Token System (Bắt buộc)

```css
/* design-system/tokens.css — PRIMITIVE TOKENS */
:root {
  /* Colors */
  --color-blue-50: #eff6ff;
  --color-blue-500: #3b82f6;
  --color-blue-600: #2563eb;
  --color-gray-50: #f9fafb;
  --color-gray-900: #111827;
  --color-red-500: #ef4444;
  --color-green-500: #22c55e;

  /* Spacing (4px base) */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-6: 24px;
  --space-8: 32px;

  /* Typography */
  --font-sans: 'Inter', system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
  --text-xs: 12px;
  --text-sm: 14px;
  --text-base: 16px;
  --text-lg: 18px;
  --text-xl: 20px;
  --text-2xl: 24px;
  --text-4xl: 36px;

  /* Borders */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-full: 9999px;

  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
  --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
}

/* design-system/semantics.css — SEMANTIC TOKENS */
[data-theme="light"], :root {
  /* Backgrounds */
  --bg-page: var(--color-gray-50);
  --bg-surface: #ffffff;
  --bg-elevated: #ffffff;
  --bg-muted: var(--color-gray-100);
  --bg-overlay: rgb(0 0 0 / 0.5);

  /* Text */
  --text-primary: var(--color-gray-900);
  --text-secondary: var(--color-gray-600);
  --text-muted: var(--color-gray-400);
  --text-disabled: var(--color-gray-300);
  --text-inverse: #ffffff;

  /* Brand */
  --color-brand: var(--color-blue-600);
  --color-brand-hover: var(--color-blue-700);
  --color-brand-subtle: var(--color-blue-50);

  /* Status */
  --color-success: var(--color-green-500);
  --color-error: var(--color-red-500);
  --color-warning: var(--color-amber-500);

  /* Borders */
  --border-color: var(--color-gray-200);
  --border-color-strong: var(--color-gray-400);
  --border-color-focus: var(--color-blue-500);

  /* Interactive */
  --focus-ring: 0 0 0 3px rgb(59 130 246 / 0.5);
}

[data-theme="dark"] {
  --bg-page: var(--color-gray-950);
  --bg-surface: var(--color-gray-900);
  --bg-elevated: var(--color-gray-800);
  --bg-muted: var(--color-gray-800);
  --text-primary: var(--color-gray-50);
  --text-secondary: var(--color-gray-400);
  --border-color: var(--color-gray-700);
  --color-brand: var(--color-blue-400);
}

/* design-system/animations.css — MOTION TOKENS */
:root {
  --duration-fast: 150ms;
  --duration-normal: 250ms;
  --duration-slow: 400ms;
  --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
  --ease-out: cubic-bezier(0, 0, 0.2, 1);
  --ease-spring: cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

/* Respect reduced motion — BẮT BUỘC */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

### Tailwind v4 Config (nếu dùng Tailwind)

```css
/* app/globals.css — Tailwind v4 CSS-first config */
@import "tailwindcss";

@theme {
  --color-brand: var(--color-blue-600);
  --font-sans: var(--font-sans);
  /* Map design tokens → Tailwind */
}
```

---

## MODE 4 — `/frontend typescript` (Strict Patterns)

### API Response Typing

```typescript
// types/api.types.ts
export interface ApiResponse<T> {
  data: T
  meta?: {
    total?: number
    page?: number
    perPage?: number
  }
}

export interface ApiError {
  message: string
  code: string
  errors?: Record<string, string[]>
}

// ✅ Typed API call
async function fetchUser(id: string): Promise<ApiResponse<User>> {
  const res = await fetch(`/api/users/${id}`)
  if (!res.ok) {
    const error: ApiError = await res.json()
    throw new Error(error.message)
  }
  return res.json()
}
```

### Error Boundaries

```typescript
// components/organisms/ErrorBoundary.tsx
'use client'  // Next.js — Client Component bắt buộc cho Error Boundaries

interface ErrorBoundaryProps {
  fallback: React.ComponentType<{ error: Error; reset: () => void }>
  children: React.ReactNode
}

// Mọi route PHẢI có error.tsx trong Next.js App Router
// app/(dashboard)/error.tsx
export default function DashboardError({
  error, reset
}: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div role="alert" aria-live="assertive">
      <h2>Something went wrong</h2>
      <button onClick={reset}>Try again</button>
    </div>
  )
}
```

---

## CHECKLIST KIẾN TRÚC (trước khi code feature đầu tiên)

```
STRUCTURE:
[ ] File structure theo Atomic Design (atoms/molecules/organisms/templates/pages)
[ ] Barrel exports setup (components/index.ts, types/index.ts)
[ ] Path aliases trong tsconfig.json
[ ] TypeScript strict mode bật

DESIGN SYSTEM:
[ ] tokens.css — Primitive tokens định nghĩa
[ ] semantics.css — Semantic tokens (light + dark)
[ ] animations.css — Motion tokens + prefers-reduced-motion
[ ] Không hardcode color/font/spacing trong component

COMPONENT STANDARDS:
[ ] forwardRef cho tất cả interactive atoms
[ ] displayName set cho tất cả forwardRef
[ ] aria attributes cơ bản (aria-label, aria-busy, aria-disabled)
[ ] className prop cho tất cả atoms (extensible)
[ ] Component API docs trong mỗi component folder

TYPESCRIPT:
[ ] Explicit interface cho mỗi component props
[ ] No any, no @ts-ignore (phải có // eslint-disable comment với lý do)
[ ] Zod validation cho mọi form input + API response

TESTING BASELINE:
[ ] Unit test cho utility functions
[ ] Component test cho interactive atoms (Button, Input, Form)
[ ] Integration test cho organisms có business logic
```

---

## QUY TẮC

- ❌ KHÔNG mix Atomic levels (organism import molecule từ organisms khác — tạo organism mới)
- ❌ KHÔNG style bằng inline styles cho theme colors
- ❌ KHÔNG dùng `any` type
- ✅ LUÔN type API responses với Zod hoặc explicit interfaces
- ✅ LUÔN có error.tsx + loading.tsx cho mọi route group (Next.js)
- ✅ LUÔN test responsive: 480px / 768px / 1024px / 1440px
