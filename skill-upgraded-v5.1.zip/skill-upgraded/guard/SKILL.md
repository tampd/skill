---
name: Guard — Quality Assurance Workflow (v5.1)
description: "Quality gate toàn diện: TDD tests + WCAG accessibility audit + security check + performance + Lighthouse CI. Dùng khi cần audit quality trước ship, viết tests, hoặc kiểm tra code đã đạt chuẩn chưa. Kích hoạt bằng /guard [scope]."
---

# /guard [scope]

> **4-in-1** — Tests + Accessibility + Security + Performance
> Mục tiêu: Code an toàn, accessible, performant, có test coverage

---

## 4 MODES

### Mode 1 — `/guard test [module]`

> ⚠️ **TDD Rule 6**: Tests phải viết TRƯỚC code (RED→GREEN→REFACTOR).

```
1. Identify testable units:
   - Service methods với business logic
   - Controller endpoints
   - Hooks với side effects
   - Edge cases từ LESSONS.md

2. Test pyramid:
   Unit (70%):    Service/util functions, isolated
   Integration (20%): API endpoints, DB operations
   E2E (10%):    Critical user journeys (checkout, auth)

3. Test specs:
   Unit tests (*.test.ts / *.spec.ts):
   - Happy path: input hợp lệ → output đúng
   - Edge cases: null, empty, zero, negative, max length
   - Error cases: invalid input → proper error thrown

   API tests:
   - 200: valid request → correct response shape
   - 400/422: invalid input → error details
   - 401: no token → unauthorized
   - 403: wrong role → forbidden
   - 404: not found

   Component tests (React Testing Library):
   - Render: snapshot hoặc getByRole
   - Interaction: userEvent.click/type
   - Accessibility: getByRole, getByLabelText (semantic queries)
   - Async: waitFor, findBy

4. Run:
   npm test -- --coverage --testPathPattern=[module]
```

```typescript
// ✅ Component test với semantic queries (best practice)
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Button } from '@/components/atoms/Button'

describe('Button', () => {
  it('renders with accessible label', () => {
    render(<Button>Submit form</Button>)
    expect(screen.getByRole('button', { name: /submit form/i })).toBeInTheDocument()
  })

  it('shows loading state accessibly', () => {
    render(<Button isLoading>Submit</Button>)
    const btn = screen.getByRole('button')
    expect(btn).toHaveAttribute('aria-busy', 'true')
    expect(screen.getByText(/loading/i)).toHaveClass('sr-only')
  })

  it('prevents click when disabled', async () => {
    const onClick = vi.fn()
    render(<Button disabled onClick={onClick}>Submit</Button>)
    await userEvent.click(screen.getByRole('button'))
    expect(onClick).not.toHaveBeenCalled()
  })
})
```

---

### Mode 2 — `/guard a11y [page/component]`

> WCAG 2.2 AA — BẮT BUỘC cho mọi user-facing page.

```bash
# Automated: axe-core integration test
npm install --save-dev @axe-core/playwright axe-core

# Hoặc dùng jest-axe
npm install --save-dev jest-axe
```

```typescript
// ✅ Automated axe test cho mỗi page
import { render } from '@testing-library/react'
import { axe, toHaveNoViolations } from 'jest-axe'
import HomePage from '@/app/page'

expect.extend(toHaveNoViolations)

describe('Accessibility', () => {
  it('Home page has no axe violations', async () => {
    const { container } = render(<HomePage />)
    const results = await axe(container)
    expect(results).toHaveNoViolations()
  })
})
```

```
MANUAL CHECKLIST (bổ sung automated):

KEYBOARD NAVIGATION:
[ ] Tab qua tất cả interactive elements theo thứ tự logic
[ ] Shift+Tab ngược lại
[ ] Enter/Space kích hoạt buttons
[ ] Escape đóng modals/dropdowns
[ ] Arrow keys navigate menu/listbox
[ ] Focus không bị mất sau async operations
[ ] Modal: focus trap bên trong (Tab không thoát ra ngoài)
[ ] Sau đóng modal: focus return về trigger element

SCREEN READER (test với VoiceOver/NVDA):
[ ] Headings hierarchy rõ (H1 > H2 > H3, không skip)
[ ] Tất cả images có alt text meaningful
[ ] Icon buttons có aria-label
[ ] Form errors được announce
[ ] Dynamic content changes: role="status" hoặc role="alert"
[ ] Tables có caption + scope headers
[ ] Links: text mô tả destination (không "click here")

CONTRAST (check với Chrome DevTools):
[ ] Normal text (< 18px / 14px bold): ratio ≥ 4.5:1
[ ] Large text (≥ 18px / 14px bold): ratio ≥ 3:1
[ ] UI components (borders, icons): ratio ≥ 3:1 vs background
[ ] Focus indicator: ratio ≥ 3:1 vs adjacent colors
[ ] Dark mode: verify tất cả trên lại
```

---

### Mode 3 — `/guard security`

```
OWASP TOP 10 + HEADERS CHECKLIST:

XSS PREVENTION:
[ ] React/Vue auto-escaping được dùng (không dangerouslySetInnerHTML với user input)
[ ] DOMPurify cho rich text/HTML content
[ ] CSP header configured (script-src, style-src)
[ ] No eval(), Function(), innerHTML với user data

INJECTION:
[ ] SQL: parameterized queries / ORM (Prisma, TypeORM, Mongoose)
[ ] NoSQL: sanitize operators ($where, $regex)
[ ] Command injection: không shell.exec(userInput)
[ ] Path traversal: validate file paths, no ../

AUTH & SESSION:
[ ] Passwords: bcrypt/argon2 (cost factor ≥ 12)
[ ] JWT: verify signature + expiry + issuer
[ ] Session cookies: httpOnly + Secure + SameSite=Strict
[ ] CSRF: SameSite cookie hoặc CSRF token
[ ] Rate limiting: login endpoint (5 attempts / 15 min)
[ ] Account lockout sau brute force

SECURITY HEADERS (next.config.js):
[ ] Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
[ ] X-Frame-Options: SAMEORIGIN
[ ] X-Content-Type-Options: nosniff
[ ] Referrer-Policy: strict-origin-when-cross-origin
[ ] Permissions-Policy: camera=(), microphone=(), geolocation=()
[ ] Content-Security-Policy: configured (không * cho script-src)

SUPPLY CHAIN:
[ ] npm audit / yarn audit: 0 critical
[ ] Lock files committed (package-lock.json / yarn.lock)
[ ] Dependabot / Snyk enabled
[ ] No postinstall scripts từ unknown packages
```

---

### Mode 4 — `/guard performance`

```
LIGHTHOUSE TARGETS (Mobile — strict):
[ ] Performance: ≥ 90
[ ] Accessibility: ≥ 90
[ ] Best Practices: ≥ 95
[ ] SEO: ≥ 95

CORE WEB VITALS:
[ ] LCP < 2.5s: LCP image có priority={true} + preload link?
[ ] CLS < 0.1: Images có explicit width/height? Fonts có font-display:swap?
[ ] INP < 200ms: Heavy computation trong useEffect không blocking main thread?

BUNDLE:
[ ] First Load JS < 150KB gzip (next-bundle-analyzer)
[ ] Dynamic imports cho heavy components (charts, editors, maps)
[ ] No duplicate dependencies trong bundle

BACKEND:
[ ] N+1 queries: with() / include eager loading
[ ] Missing indexes: EXPLAIN ANALYZE cho slow queries
[ ] Response gzip/brotli enabled
[ ] Cache-Control headers appropriate
```

---

## OUTPUT FORMAT

```
🛡️ GUARD REPORT — [module/scope]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧪 TESTS:        [N/M pass | ❌ N failures | Coverage: X%]
♿ ACCESSIBILITY: [✅ 0 violations | ⚠️ N warnings | 🛑 N critical]
🔒 SECURITY:     [✅ Clean | ⚠️ N warnings | 🛑 N critical]
⚡ PERFORMANCE:  [Lighthouse: P:XX A:XX BP:XX SEO:XX]

🔴 CRITICAL — Fix before merge:
  1. [Type]: [Issue] → [Location] → [Fix]

🟡 WARNINGS — Fix this sprint:
  1. [Type]: [Issue] → [Location] → [Fix]

✅ PASSING: [N checks]
```
