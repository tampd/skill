# GEMINI — Skill Repository v5.1 (Website-Optimized)

> **GitHub**: https://github.com/tampd/skill
> **Local path**: /root/skill
> **Cập nhật**: 2026-03-05 — **v5.1 WEBSITE UPGRADE**

---

## 🔑 THÔNG TIN QUAN TRỌNG

### Skill System v5.1 — Website Upgrade
Phiên bản 5.1 nâng cấp từ v5.0 (15 skills → 18 skills), tập trung **website quality**:
- 🆕 **frontend**: Atomic Design + TypeScript strict + CSS token architecture
- 🆕 **perf**: Core Web Vitals + Lighthouse CI + Bundle optimization
- 🆕 **ship**: Production readiness checklist + CI/CD pipeline + Monitoring
- ⬆ **design**: WCAG accessibility + Animation system + Component API docs
- ⬆ **guard**: axe-core a11y testing + Lighthouse CI targets + WCAG 2.2
- ⬆ **web-security**: CSP builder + Cookie security + HTTPS enforcement
- Giữ nguyên: start, build, fix, save, plan, integrate, n8n-pro, brainstorm, review-website, docs, seo, memory, qdrant-memory

### Triết lý v5.1: "Beautiful, Sustainable, Secure by Default"
```
✅ Atomic Design: Atoms → Molecules → Organisms → Templates → Pages
✅ Token-First: Design tokens → Semantic tokens → Component styles
✅ A11y First: WCAG AA mandatory trên mọi component
✅ Performance Budget: Lighthouse ≥ 90, LCP < 2.5s, CLS < 0.1
✅ Security Headers: CSP + HSTS + X-Frame-Options mặc định
✅ TDD Iron Law: Test before code (từ v5.0)
✅ Spec-Driven: Change folders (từ v5.0)
✅ 5-Layer Memory (từ v4.1)
```

### GitHub Repository
```
URL:    https://github.com/tampd/skill
Remote: origin → git@github.com:tampd/skill.git (SSH)
Branch: main
SSH Key: SHA256:nTSlO07MbIplXX/j2FAHlyuSb+MJxPO1yboDHJJidFs
```

> **RULE**: Mọi dự án đều push qua SSH (`git@github.com:`), KHÔNG dùng HTTPS.

---

## ⚠️ GLOBAL RULES

### Rule 1: AI PHẢI HỎI KHI CHƯA RÕ
> Nếu yêu cầu chưa rõ nghĩa, thiếu thông tin, hoặc mâu thuẫn:
> 🛑 AI PHẢI HỎI user TRƯỚC KHI lập kế hoạch, viết code, ghi docs.

### Rule 2: ĐỌC LESSONS TRƯỚC KHI CODE
> Mỗi task PHẢI bắt đầu bằng việc đọc LESSONS.md + grep tags liên quan.

### Rule 3: EVIDENCE-BASED VERIFICATION
> Không chấp nhận "nó chạy rồi". Phải có: curl output, test results, screenshot, log.

### Rule 4: ARCHITECTURE SPEC TRƯỚC KHI CODE
> Project mới hoặc module mới ≥ 3 files → BẮT BUỘC tạo `.spec.md` trước.

### Rule 5: BEADS CHO TASK TRACKING
> Nếu dự án có `.beads/` → dùng `bd` CLI. Nếu không → dùng NEXT-TODO.md.

### Rule 6: TDD IRON LAW
> Viết test TRƯỚC code. RED → GREEN → REFACTOR → COMMIT.
> **Exceptions** (hỏi user): throwaway prototype, config files, generated code, CSS-only.

### Rule 7: BRAINSTORMING HARD GATE
> `/plan` PHẢI hỏi clarifying questions + propose 2-3 approaches TRƯỚC.

### Rule 8: ROOT CAUSE TRƯỚC FIX
> `/fix` PHẢI xong Phase 1 (Root Cause Investigation) TRƯỚC KHI fix.

### Rule 9: ACCESSIBILITY MANDATORY (MỚI v5.1)
> Mọi user-facing component PHẢI pass WCAG AA.
> axe DevTools = 0 violations trước khi merge.
> KHÔNG xóa focus outline mà không thay thế bằng custom focus ring.

### Rule 10: SECURITY HEADERS MANDATORY (MỚI v5.1)
> Mọi website production PHẢI có đủ security headers trước launch.
> Xem `/ship check` → security headers checklist.
> CSP, HSTS, X-Frame-Options, X-Content-Type-Options là BẮT BUỘC.

### Rule 11: DESIGN TOKEN MANDATORY (MỚI v5.1)
> KHÔNG hardcode colors, fonts, spacing trong components.
> Mọi giá trị visual PHẢI qua semantic design tokens.
> --bg-surface, --text-primary, --color-brand, v.v.

### Rule 12: PERFORMANCE BUDGET (MỚI v5.1)
> Lighthouse Performance (mobile) PHẢI ≥ 90 trước khi launch.
> LCP < 2.5s, CLS < 0.1, INP < 200ms.
> First Load JS < 150KB gzip.

---

## 📁 CẤU TRÚC SKILL REPOSITORY v5.1

```
/root/skill/
├── GEMINI.md                ← File này — brain & rules
├── README.md                ← Hướng dẫn cài đặt
│
│── ─── 8 CORE SKILLS (v5.0+) ───
├── start/SKILL.md           ← /start [task]          Memory Bootstrap
├── build/SKILL.md           ← /build [task] ⭐       🔥 TDD Iron Law
├── fix/SKILL.md             ← /fix [bug]             🔥 4-Phase Systematic Debug
├── save/SKILL.md            ← /save                  🔥 2-Stage Review + Archive
├── plan/SKILL.md            ← /plan [feature]        🔥 Change Folder + Hard Gate
├── design/SKILL.md          ← /design [task] ⬆       🆕 WCAG A11y + Animation System
├── guard/SKILL.md           ← /guard [scope] ⬆       🆕 axe-core + Lighthouse CI
├── integrate/SKILL.md       ← /integrate [svc]       API + 3rd-party
│
│── ─── 3 NEW WEBSITE SKILLS (v5.1) ───
├── frontend/SKILL.md        ← /frontend [task] 🆕    Atomic Design + TS strict + CSS tokens
├── perf/SKILL.md            ← /perf [target] 🆕      Core Web Vitals + Bundle + Caching
├── ship/SKILL.md            ← /ship [scope] 🆕       Pre-launch checklist + CI/CD + Monitor
│
│── ─── SKILLS GIỮ NGUYÊN ───
├── n8n-pro/SKILL.md         ← /n8n [task]            MCP Server + Sub-workflows
├── brainstorm/SKILL.md      ← /brainstorm [idea]     Ideation Pipeline
├── web-security/SKILL.md    ← /security [target] ⬆  🆕 CSP + HTTPS + Cookie security
├── review-website/SKILL.md  ← /review-web [url]      7-dimension audit
├── docs/SKILL.md            ← /docs [scope]          Documentation + ADR
├── seo/SKILL.md             ← /seo [topic]           SEO + GEO content
├── memory/SKILL.md          ← /memory                5-Layer Memory
│
│── ─── INFRASTRUCTURE ───
├── qdrant-memory/SKILL.md   ← Qdrant Layer 4 setup
└── archive/                 ← Skills cũ (preserved)
```

---

## 🎯 18 SKILLS — QUICK REFERENCE

| # | Skill | Lệnh | Mục đích | Version |
|---|---|---|---|---|
| 1 | **start** | `/start [task]` | Khởi động phiên + Memory recall | v5.0 |
| 2 | **build** ⭐ | `/build [task]` | 🔥 TDD Iron Law + Spec Compliance | v5.0 |
| 3 | **fix** | `/fix [bug]` | 🔥 4-Phase Systematic Debug | v5.0 |
| 4 | **save** | `/save` | 🔥 2-Stage Review + Archive | v5.0 |
| 5 | **plan** | `/plan [feature]` | 🔥 Change Folder + Hard Gate | v5.0 |
| 6 | **design** | `/design [task]` | WCAG A11y + Animation + Token system | ⬆ v5.1 |
| 7 | **guard** | `/guard [scope]` | axe-core + Lighthouse CI + Security | ⬆ v5.1 |
| 8 | **integrate** | `/integrate [svc]` | API + 3rd-party + webhook | v5.0 |
| 9 | **frontend** 🆕 | `/frontend [task]` | Atomic Design + TypeScript + CSS tokens | 🆕 v5.1 |
| 10 | **perf** 🆕 | `/perf [target]` | Core Web Vitals + Bundle + Caching | 🆕 v5.1 |
| 11 | **ship** 🆕 | `/ship [scope]` | Pre-launch + CI/CD + Monitor + Rollback | 🆕 v5.1 |
| 12 | **n8n-pro** | `/n8n [task]` | N8N + MCP Server + Sub-workflows | v3.0 |
| 13 | **brainstorm** | `/brainstorm [idea]` | Ideation → Spec → Prototype | v3.0 |
| 14 | **web-security** | `/security [target]` | OWASP + CSP + Headers + HTTPS | ⬆ v5.1 |
| 15 | **review-website** | `/review-web [url]` | Website review 7 dimensions | v3.0 |
| 16 | **docs** | `/docs [scope]` | Documentation + ADR + Handoff | v4.0 |
| 17 | **seo** | `/seo [topic]` | SEO + GEO content writer | v4.0 |
| 18 | **memory** | `/memory` `/checkpoint` `/recall` | 5-Layer Memory | v4.1 |

---

## 🌐 WEBSITE DEVELOPMENT WORKFLOW v5.1

```
/frontend setup     →  /design [component]  →  /guard a11y  →  /perf  →  /ship check
      │                      │                      │              │            │
   Stack choice          Token system          WCAG audit    Web Vitals   Pre-launch
   File structure        ARIA attrs            axe DevTools   Lighthouse  Security headers
   TS config            Animation             0 violations   ≥90 score   CI/CD pipeline
                        Component API docs
```

### Typical Website Sprint Workflow

```
FEATURE MỚI:
/plan [feature]         → Change folder + Spec + Tasks
/frontend components    → Atomic Design structure
/design [component]     → UI + ARIA + Tokens + Animation
/build [task]           → TDD implementation
/guard a11y             → WCAG verification
/guard test [module]    → Unit + integration tests
/perf                   → Web Vitals check
/save                   → 2-stage review + commit

PRÉ-LAUNCH:
/guard security         → OWASP + security headers
/security [target]      → Deep audit
/perf all               → Lighthouse CI
/ship check             → Full pre-launch checklist
/ship ci                → CI/CD pipeline setup
/ship monitor           → Monitoring + alerts
```

---

## 🧠 MEMORY ARCHITECTURE (5 Tầng)

| Tầng | Engine/File | Mục đích | Skill tương tác |
|---|---|---|---|
| **1 — Working** | `ACTIVE_CONTEXT.md` | Session memory | /checkpoint, /recall |
| **2 — Semantic** | `GEMINI.md`, `STATE.md`, `NEXT-TODO.md` | Project brain | /start, /save |
| **3 — Episodic** | `LESSONS.md`, `CHANGE_LOG.md` | Long-term memory | /fix, /save |
| **4 — Vector** | **Qdrant** MCP | Semantic search cross-session | /start, /build, /fix |
| **5 — Task Graph** | **Beads** CLI | Dependency-aware tasks | /start, /build, /save |

---

## 📋 CHEAT SHEET v5.1

```
Bắt đầu phiên?           → /start [task]
Setup dự án web mới?      → /frontend setup       🆕 Atomic Design + TS strict
Viết code?                → /build [task]         🔥 TDD Iron Law
G��p bug?                  → /fix [bug]            🔥 4-Phase Systematic
Feature phức tạp?         → /plan [feature]       🔥 Change Folder
Design / UI component?    → /design [task]        ⬆ WCAG A11y + Animation
Test / audit?             → /guard [scope]        ⬆ axe-core + Lighthouse CI
Performance?              → /perf [target]        🆕 Core Web Vitals
Chuẩn bị deploy?          → /ship check           🆕 Pre-launch checklist
Setup CI/CD?              → /ship ci              🆕 GitHub Actions pipeline
API / webhook?            → /integrate [service]
N8N workflow?             → /n8n [task]
Cần ý tưởng?             → /brainstorm [idea]
Audit bảo mật sâu?        → /security [target]    ⬆ CSP + Headers
Review website?           → /review-web [url]
Viết docs / handoff?      → /docs [scope]
Viết bài SEO?             → /seo [topic]
Lưu context?              → /checkpoint
Kết thúc phiên?           → /save                 🔥 2-Stage Review
```

---

## 📝 CHANGE LOG

| Date | Change |
|---|---|
| **2026-03-05** | **v5.1 WEBSITE UPGRADE**: +3 skills (frontend, perf, ship). Nâng cấp design (WCAG a11y + animation system), guard (axe-core + Lighthouse CI + WCAG 2.2), web-security (CSP builder + HTTPS + cookie security). +4 Global Rules (9-12). |
| 2026-03-05 | v5.0 HYBRID UPGRADE: TDD Iron Law, Spec-Driven, 4-Phase Debug, 2-Stage Review. |
| 2026-03-04 | v4.1 HYBRID MEMORY: Beads + Qdrant 5-Layer Memory. |
| 2026-03-04 | v4.0 STRUCTURED VIBE: +docs, +seo skills. |
| 2026-03-04 | v3.0 EXTENDED: +brainstorm, +n8n-pro, +web-security, +review-website. |
| 2026-02-28 | v2.0: Gộp 26 skills → 8 unified skills. |
