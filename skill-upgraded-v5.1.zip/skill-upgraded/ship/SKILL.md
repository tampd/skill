---
name: Ship — Production Readiness & Deployment Checklist
description: "Chuẩn bị và deploy website lên production: environment setup, pre-launch checklist, CI/CD pipeline, monitoring, rollback plan. Dùng trước khi launch website mới, deploy feature lớn, hoặc setup CI/CD pipeline. Kích hoạt bằng /ship [scope]."
---

# /ship [scope: check | deploy | ci | monitor]

> **Production Readiness** — KHÔNG deploy khi chưa qua checklist này
> Mục tiêu: Zero downtime deploy, instant rollback, full observability

> [!CAUTION]
> **RULE**: KHÔNG deploy trực tiếp lên production. LUÔN qua staging → test → approve → deploy.

---

## MODE 1 — `/ship check` (Pre-Launch Checklist)

### ✅ CODE QUALITY

```
[ ] TypeScript: 0 type errors (npx tsc --noEmit)
[ ] Lint: 0 errors (npm run lint)
[ ] Tests: tất cả PASS (npm test)
[ ] Build: success (npm run build)
[ ] No console.log / debugger / TODO comments trong production code
[ ] No hardcoded credentials, API keys, passwords
[ ] All secrets in environment variables
[ ] .env.example updated với mọi required variables
```

### ✅ SECURITY HEADERS (BẮT BUỘC)

```typescript
// next.config.js — Security headers
const securityHeaders = [
  {
    key: 'X-DNS-Prefetch-Control',
    value: 'on'
  },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload'
  },
  {
    key: 'X-Frame-Options',
    value: 'SAMEORIGIN'          // Chống clickjacking
  },
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff'             // Chống MIME sniffing
  },
  {
    key: 'Referrer-Policy',
    value: 'strict-origin-when-cross-origin'
  },
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=()'
  },
  {
    key: 'Content-Security-Policy',
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://trusted-cdn.com",  // Thêm domains cần thiết
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https:",
      "font-src 'self' https://fonts.gstatic.com",
      "connect-src 'self' https://api.yoursite.com",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join('; ')
  },
]

module.exports = {
  async headers() {
    return [
      {
        source: '/:path*',
        headers: securityHeaders,
      },
    ]
  },
}
```

```bash
# Verify security headers sau deploy
curl -I https://yoursite.com | grep -i "strict-transport\|x-frame\|content-security\|x-content-type"

# Kiểm tra tự động với securityheaders.com
# Target: A+ rating
```

### ✅ PERFORMANCE

```
[ ] Lighthouse Performance ≥ 90 (mobile)
[ ] Lighthouse Accessibility ≥ 90
[ ] LCP < 2.5s
[ ] CLS < 0.1
[ ] Images: WebP format, explicit dimensions, lazy loading (ngoại trừ LCP)
[ ] Fonts: preloaded, font-display: swap
[ ] Bundle: First Load JS < 150KB gzip
```

### ✅ SEO

```
[ ] title tag: unique, ≤ 60 chars, mỗi page
[ ] meta description: compelling, ≤ 155 chars
[ ] Open Graph tags: og:title, og:description, og:image (1200x630), og:url
[ ] robots.txt present (không block important pages)
[ ] sitemap.xml present và submit cho Google Search Console
[ ] Canonical URLs set
[ ] Structured data (Schema.org) cho relevant content
[ ] Redirect http → https
[ ] Redirect www → non-www (hoặc ngược lại, chọn 1)
[ ] No broken links (test với Screaming Frog hoặc broken-link-checker)
```

### ✅ ACCESSIBILITY

```
[ ] Keyboard navigation: Tab qua tất cả interactive elements
[ ] Skip to main content link (cho screen readers)
[ ] ARIA labels cho icons, form fields không rõ label
[ ] Color contrast ≥ 4.5:1 (WCAG AA) — test với axe DevTools
[ ] Images có alt text (decorative = alt="")
[ ] Forms: label liên kết với input (htmlFor / aria-labelledby)
[ ] Error messages: rõ ràng, referenced bằng aria-describedby
[ ] Focus visible: không xóa outline mà không thay thế
[ ] lang attribute trên <html>
```

### ✅ ENVIRONMENT

```
[ ] .env.production không commit vào git
[ ] Mọi required env vars có trong deployment platform
[ ] Database: production URL, connection pool setting
[ ] API keys: production keys (khác development)
[ ] CORS: chỉ allow production domain
[ ] Rate limiting: bật trên production
[ ] Error tracking: Sentry hoặc tương đương setup
[ ] Analytics: Google Analytics / Plausible setup
```

---

## MODE 2 — `/ship ci` (CI/CD Pipeline)

### GitHub Actions Pipeline (Next.js)

```yaml
# .github/workflows/ci.yml
name: CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

env:
  NODE_VERSION: '20'

jobs:
  quality:
    name: Code Quality
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'

      - run: npm ci

      - name: TypeScript Check
        run: npx tsc --noEmit

      - name: Lint
        run: npm run lint

      - name: Tests
        run: npm test -- --coverage --ci

      - name: Upload Coverage
        uses: codecov/codecov-action@v4

  build:
    name: Build
    needs: quality
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
      - run: npm ci
      - run: npm run build
        env:
          NEXT_PUBLIC_API_URL: ${{ vars.NEXT_PUBLIC_API_URL }}

  lighthouse:
    name: Lighthouse CI
    needs: build
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
      - run: npm ci && npm run build
      - name: Run Lighthouse CI
        uses: treosh/lighthouse-ci-action@v11
        with:
          urls: |
            http://localhost:3000
            http://localhost:3000/about
          budgetPath: './lighthouse-budget.json'
          uploadArtifacts: true

  deploy-staging:
    name: Deploy to Staging
    needs: build
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/develop'
    environment: staging
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Vercel (Staging)
        uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}

  deploy-production:
    name: Deploy to Production
    needs: [build, lighthouse]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    environment:
      name: production
      url: https://yoursite.com
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Vercel (Production)
        uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'
```

### Lighthouse Budget

```json
// lighthouse-budget.json
[
  {
    "resourceSizes": [
      { "resourceType": "script", "budget": 150 },
      { "resourceType": "image", "budget": 500 },
      { "resourceType": "total", "budget": 800 }
    ],
    "timings": [
      { "metric": "interactive", "budget": 3000 },
      { "metric": "first-contentful-paint", "budget": 1500 },
      { "metric": "largest-contentful-paint", "budget": 2500 }
    ],
    "categories": [
      { "id": "performance", "minScore": 0.9 },
      { "id": "accessibility", "minScore": 0.9 },
      { "id": "best-practices", "minScore": 0.95 },
      { "id": "seo", "minScore": 0.95 }
    ]
  }
]
```

---

## MODE 3 — `/ship monitor` (Monitoring Setup)

### Error Tracking (Sentry)

```typescript
// lib/sentry.ts
import * as Sentry from '@sentry/nextjs'

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
  beforeSend(event) {
    // Không gửi errors từ dev
    if (process.env.NODE_ENV === 'development') return null
    return event
  }
})
```

### Health Check Endpoint

```typescript
// app/api/health/route.ts
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Check database connection
    await db.$queryRaw`SELECT 1`

    return Response.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      version: process.env.npm_package_version,
      checks: { database: 'ok' }
    })
  } catch (error) {
    return Response.json(
      { status: 'error', checks: { database: 'error' } },
      { status: 503 }
    )
  }
}
```

### Uptime Monitoring

```
MONITORING SETUP CHECKLIST:
[ ] Uptime monitor (Uptime Robot free / BetterUptime): ping /api/health mỗi 5 phút
[ ] Alert khi downtime: email + Slack/Telegram
[ ] Error tracking: Sentry DSN configured
[ ] Analytics: Plausible (privacy-first) hoặc GA4
[ ] Performance monitoring: Vercel Analytics hoặc SpeedCurve
[ ] Core Web Vitals: Real User Monitoring bật
```

---

## MODE 4 — `/ship rollback` (Emergency Rollback)

```bash
# Vercel instant rollback (< 30 giây)
vercel rollback [deployment-url]

# Git revert + force deploy
git revert HEAD --no-edit
git push origin main

# Feature flag disable (nếu dùng feature flags)
# → Toggle flag trong LaunchDarkly / Unleash để disable ngay lập tức
```

```
ROLLBACK DECISION TREE:
1. Error rate tăng > 1%? → Rollback ngay
2. LCP > 4s sau deploy? → Rollback + investigate
3. Core functionality broken? → Rollback ngay
4. Minor UI bug? → Hotfix deploy (không rollback)

ROLLBACK SLA:
  Phát hiện issue → Quyết định: < 5 phút
  Rollback execution: < 2 phút (Vercel/Netlify instant rollback)
  Communication: < 10 phút (notify stakeholders)
```

---

## OUTPUT FORMAT

```
🚀 SHIP REPORT — [Project Name] v[version]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 PRE-LAUNCH CHECKLIST
  Code Quality:    [✅ PASS | 🛑 FAIL]
  Security:        [✅ PASS | 🛑 FAIL]
  Performance:     [✅ PASS | 🛑 FAIL]
  SEO:             [✅ PASS | 🛑 FAIL]
  Accessibility:   [✅ PASS | 🛑 FAIL]
  Environment:     [✅ PASS | 🛑 FAIL]

🚦 DEPLOY DECISION
  [✅ READY TO SHIP | 🛑 BLOCKED — fix N issues first]

⚠️ BLOCKERS (phải fix trước khi deploy)
  1. [Issue] — [Location] — [How to fix]

🟡 POST-DEPLOY TASKS
  1. [Task] — [Deadline]
```
