# CHANGELOG

## v2.0.0 — 2026-03-10

### Breaking Changes
- `session/SKILL.md`: /save bây giờ bắt buộc chạy verification loop trước khi save state
- `build/SKILL.md`: TDD Hard Gate — không thể skip test phase

### New Features
- `build`: TDD Hard Gate với coverage ≥80% enforcement
- `build`: SELF-REASONING GATE (3-question check trước implement)
- `build`: Antigravity PLAN-FIRST với task-list có checkpoints
- `session`: Full Verification Loop (lint→format→type-check→test→audit)
- `session`: /review command — multi-perspective (Security/Performance/Maintainability)
- `spec`: /apidoc — OpenAPI-compatible API documentation
- `spec`: /componentdoc — Component library reference docs
- `content`: /brief — Content brief trước khi viết article
- `content`: /audit-content — SEO audit cho existing content
- `secure`: /harden — Security headers + hardening configuration
- `learn`: Instinct Feedback Loop (correct +0.1, wrong -0.2, partial +0.02)
- `learn`: Auto-prune candidates khi confidence <0.30 sau ≥5 lần apply
- `learn`: /review-instincts — Periodic review với promote/archive/prune
- `learn`: /evolve — Cluster instincts thành formal skill sections
- `fix`: Antigravity Browser Agent workflow cho UI bugs
- `craft`: /tokens command — Design token system creation/expansion
- `craft`: Browser Sub-Agent verification workflow
- `automate`: /mcp command — MCP Tool design pattern
- `GEMINI.md`: 20 rules (up from 17), including PLAN-FIRST và SELF-REASONING GATE

### Improvements
- `fix`: 5-WHY technique trong DIAGNOSE phase
- `secure`: Full OWASP Top 10 detailed checklist
- `content`: WordPress REST API payload template
- `learn`: INSTINCTS.md schema với apply_count, success_count, failure_count
- `spec`: /handoff Section 8 expanded với API Reference
- `spec`: /runbook Section 5 expanded với symptom→diagnosis→fix table
- All skills: Progressive Disclosure pattern — SKILL.md under 500 lines

## v1.0.0 — 2026-03-01

- Initial release: 9 skills, 17 global rules, 5-layer memory
- Inspired by everything-claude-code + Skill System v7.0
