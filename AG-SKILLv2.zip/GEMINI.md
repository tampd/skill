# AG-SKILL Global Rules v2.0
> Applied to ALL sessions in this project. Read before every task.

## MEMORY FILES (read at session start)
- `LESSONS.md` — bài học từ quá khứ (append-only)
- `INSTINCTS.md` — patterns đã học + confidence score
- `STATE.md` — project state hiện tại
- `ACTIVE_CONTEXT.md` — working memory phiên này (xóa sau /save)

---

## 20 GLOBAL RULES

### Core Behavior
1. **ASK WHEN UNCLEAR** — Nếu yêu cầu mơ hồ hoặc có ≥2 cách hiểu → hỏi trước, đừng đoán
2. **READ MEMORY FIRST** — Đọc `LESSONS.md` + `INSTINCTS.md` trước bất kỳ task nào
3. **EVIDENCE-BASED** — Mọi quyết định kỹ thuật phải có lý do cụ thể, không phán đoán
4. **SELF-REASONING GATE** — Tự hỏi 3 câu trước khi implement: (a) Đây có phải cách đơn giản nhất? (b) Có test cho cái này không? (c) Bảo mật có ổn không?

### Architecture & Planning
5. **SPEC BEFORE CODE** — Task ≥3 files hoặc ≥2h effort → viết `/spec` trước, không code ngay
6. **PLAN-FIRST (Antigravity)** — Generate task list có checkpoint TRƯỚC khi bắt đầu code
7. **BRAINSTORM HARD GATE** — Feature phức tạp → `/plan` bắt buộc, không nhảy thẳng vào code
8. **ADR FOR DECISIONS** — Mọi architectural decision quan trọng → ghi `/adr` ngay lúc quyết định

### Code Quality
9. **TDD IRON LAW** — Test TRƯỚC code. Không có test = không commit. Coverage ≥80%
10. **SEARCH-FIRST** — Tìm package/solution có sẵn trước khi tự viết. Ưu tiên: official > popular > custom
11. **QUALITY GATE** — Trước mỗi commit: `lint → format → type-check → test → audit`. Tất cả PASS mới commit
12. **CLEANUP PASS** — Sau implement + verify → review riêng pass chỉ để tìm: dead code, TODO cũ, console.log, magic numbers

### Verification
13. **ROOT CAUSE FIRST** — Bug: tìm nguyên nhân gốc trước khi fix. Không patch symptom
14. **VERIFICATION LOOP** — Sau mỗi implementation: run lint→test→diff→regression check. Chỉ báo "done" khi tất cả pass
15. **INSTINCT VALIDATION** — Khi apply instinct → log kết quả. Đúng: +0.1. Sai: −0.2. Dưới 0.3 sau 5 lần → xem xét xóa

### Design & UX
16. **WCAG AA** — Mọi UI component phải đạt WCAG 2.2 AA. Color contrast, keyboard nav, aria-label
17. **DESIGN TOKEN MANDATORY** — Không dùng hardcoded color/spacing/font. Luôn dùng design tokens
18. **PERFORMANCE BUDGET** — LCP ≤2.5s, CLS ≤0.1, FID ≤100ms. Measure before/after feature

### Standards
19. **SECURITY HEADERS** — Mọi HTTP response phải có: CSP, HSTS, X-Frame-Options, X-Content-Type
20. **README SYNC** — Sau mỗi push: kiểm tra README có cần cập nhật không (API changes, new env vars, new commands)

---

## ANTIGRAVITY NATIVE FEATURES — Sử dụng tích cực

```
Browser Sub-Agent    → /craft, /fix UI bugs, /e2e verification
Multi-Agent Parallel → /build large features (split thành sub-tasks)
Mission Control      → Monitor parallel agents, assign /spec + /build + /secure cùng lúc
Artifact Output      → /spec, /handoff, /runbook output dạng structured Artifact
Planning Mode        → Luôn gen task-list có checkpoint trước khi code
```

---

## SKILL MAP

| Trigger | Skill |
|---------|-------|
| Bắt đầu / kết thúc phiên | `session` |
| Viết code mới, feature | `build` |
| Debug, lỗi, crash | `fix` |
| UI, design, component | `craft` |
| Security, deploy, production | `secure` |
| N8N, API, automation | `automate` |
| Bài viết, SEO, content | `content` |
| Architecture, docs, handoff | `spec` |
| Học hỏi, patterns, instincts | `learn` |
