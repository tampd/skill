# AG-SKILL — Antigravity Skill System v2.0

> **Tinh hoa của [everything-claude-code](https://github.com/affaan-m/everything-claude-code) + Skill System v7.0, được tối ưu hoàn toàn cho Google Antigravity.**

```
"CODE ÍT LỖI HƠN. DOCS CHUYÊN NGHIỆP HƠN. HỌC HỎI LIÊN TỤC. KHAI THÁC TRIỆT ĐỂ ANTIGRAVITY."
```

## Nâng cấp từ v1.0 → v2.0

| Feature | v1.0 | v2.0 |
|---------|------|------|
| TDD | Rule tuyên bố | **Hard gate: test trước, coverage ≥80%, không bypass** |
| Verification | /checkpoint cơ bản | **Full loop: lint→format→type-check→test→audit sau mỗi task** |
| Spec/Docs | 15 sections | **+/apidoc, +/componentdoc → handoff thực sự hoàn chỉnh** |
| Instinct | Confidence scoring | **Feedback loop: correct+0.1, wrong-0.2, auto-prune <0.3** |
| Antigravity | Sử dụng cơ bản | **Browser Agent, Parallel Agents, Mission Control, Artifacts** |
| Rules | 17 rules | **20 rules + SELF-REASONING GATE + PLAN-FIRST** |

---

## 9 Skills

| # | Skill | Commands | Purpose |
|---|-------|----------|---------|
| 1 | **session** | `/start` `/save` `/checkpoint` `/review` | 🔄 Lifecycle + Quality Gate + Multi-perspective Review |
| 2 | **build** ⭐ | `/build` `/plan` `/search` | 🔥 TDD Hard Gate + Search-First + Cleanup Pass |
| 3 | **fix** | `/fix` | 🐛 4-Phase Debug + Instinct Match + Browser Verify |
| 4 | **craft** | `/craft` `/audit` `/tokens` | 🎨 Atomic Design + WCAG + Browser Agent Testing |
| 5 | **secure** | `/security` `/harden` `/ship` | 🔒 OWASP Top 10 + Production Readiness |
| 6 | **automate** | `/n8n` `/integrate` `/mcp` | ⚡ N8N + API + MCP Tool Design |
| 7 | **content** | `/seo` `/article` `/brief` `/audit-content` | 📝 SEO + E-E-A-T + WordPress Pipeline |
| 8 | **spec** ⭐ | `/spec` `/handoff` `/adr` `/runbook` `/apidoc` `/componentdoc` | 📋 Ultra Docs (6 commands) |
| 9 | **learn** 🆕 | `/learn` `/instinct` `/evolve` `/review-instincts` | 🧠 Instinct Loop + Pattern Evolution |

---

## Install

```bash
# Clone
git clone git@github.com:tampd/ag-skill.git /root/skill/ag-skill

# Symlink vào Antigravity skills directory
for skill in session build fix craft secure automate content spec learn; do
  ln -sfn /root/skill/ag-skill/$skill /root/.gemini/antigravity/skills/$skill
done

# Copy GEMINI.md vào project root
cp /root/skill/ag-skill/GEMINI.md ./GEMINI.md

# Verify
ls /root/.gemini/antigravity/skills/
```

---

## Cheat Sheet

```
Bắt đầu phiên?            → /start [task]
Ý tưởng mơ hồ?            → /plan [idea]
Research package?          → /search [need]
Viết code?                 → /build [task]           🔥 TDD Hard Gate
Gặp bug?                   → /fix [bug]              🐛 4-Phase + Instinct
Design UI?                 → /craft [task]            🎨 WCAG + Browser Test
Audit quality?             → /audit [scope]
Audit bảo mật?             → /security [target]       🔒 OWASP
Hardening?                 → /harden [service]
Chuẩn bị deploy?           → /ship [env]
API / webhook?             → /integrate [service]
N8N workflow?              → /n8n [task]
Design MCP tool?           → /mcp [tool-name]
Viết bài SEO?              → /seo [topic]
Content brief?             → /brief [topic]
Architecture docs?         → /spec [scope]
Bàn giao dự án?            → /handoff [project]       📋 15 sections
API documentation?         → /apidoc [endpoint]       📋 NEW
Component docs?            → /componentdoc [scope]    📋 NEW
Ghi ADR?                   → /adr [decision]
Tạo runbook?               → /runbook [service]
Ghi bài học?               → /learn [observation]
Xem/manage instincts?      → /instinct [action]
Evolve instincts → skill?  → /evolve
Review & prune instincts?  → /review-instincts
Review code 3 góc nhìn?    → /review [scope]
Lưu giữa phiên?            → /checkpoint
Kết thúc phiên?            → /save
```

---

## Memory Architecture (5 Layers)

| Layer | File | Purpose |
|-------|------|---------|
| Working | `ACTIVE_CONTEXT.md` | Session memory (xóa sau /save) |
| Semantic | `GEMINI.md`, `STATE.md` | Project brain + global rules |
| Episodic | `LESSONS.md`, `CHANGELOG.md` | Long-term, append-only |
| Instinct | `INSTINCTS.md` | Learned patterns + confidence + feedback loop |
| Vector | Qdrant MCP (optional) | Semantic search across all files |

---

## 20 Global Rules (GEMINI.md)

**Core:** Ask when unclear · Read memory first · Evidence-based · Self-reasoning gate  
**Architecture:** Spec before code · Plan-first · Brainstorm gate · ADR for decisions  
**Code quality:** TDD iron law · Search-first · Quality gate · Cleanup pass  
**Verification:** Root cause first · Verification loop · Instinct validation  
**Design:** WCAG AA · Design token mandatory · Performance budget  
**Standards:** Security headers · README sync  

---

## Antigravity Native Features (tích cực sử dụng)

```
🌐 Browser Sub-Agent   → /craft visual verify, /fix UI bugs, E2E testing
👥 Parallel Agents     → /build large features (split Frontend/Backend/Tests)
🎛️  Mission Control    → Coordinate /spec + /build + /secure agents simultaneously
📦 Artifact Output     → /spec, /handoff, /runbook → structured deliverables
📋 Planning Mode       → Task-list với checkpoints TRƯỚC khi code
```

---

## What's New in v2.0

- **TDD Hard Gate** — không thể bypass, coverage ≥80% enforced
- **Full Verification Loop** — lint→format→type-check→test→audit, sau mỗi task
- **Instinct Feedback Loop** — correct/wrong/partial scoring, auto-prune <0.3
- **/apidoc** — OpenAPI-compatible API documentation command
- **/componentdoc** — Component library reference documentation
- **/brief** — Content brief trước khi viết article
- **/harden** — Security headers + hardening configuration
- **/review-instincts** — Periodic instinct pruning + promotion
- **SELF-REASONING GATE** — 3-question check trước implement
- **PLAN-FIRST (Antigravity)** — Task list với checkpoints, parallel agent hints
- **Browser Agent workflow** — Integrated vào /craft và /fix

---

## Inspiration

- [everything-claude-code](https://github.com/affaan-m/everything-claude-code) — Hooks, Instincts, Search-First, De-sloppify, Verification Loop
- Skill System v7.0 — Zero Overlap, Progressive Disclosure, 5-Layer Memory, Self-Reasoning Gate
- Antigravity best practices — Browser Agent, Parallel Agents, Planning-First, Artifacts

## License

MIT
